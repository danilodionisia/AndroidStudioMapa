package com.example.mapas2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    EditText editTextLatitude, editTextLongitude, editTextNome;
    Button buttonVerMapa, buttonCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editTextNome = findViewById(R.id.editTextNome);
        editTextLatitude = findViewById(R.id.editTextLatitude);
        editTextLongitude = findViewById(R.id.editTextLongitude);

        buttonCadastrar = findViewById(R.id.buttonCadastrar);
        buttonVerMapa = findViewById(R.id.buttonVerMapa);

        //abre a acitivity que exibe os mapas
        buttonVerMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent mapa = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(mapa);

            }
        });

        buttonCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Mapa mapa =  new Mapa();

                mapa.setLatitude(editTextLatitude.getText().toString());
                mapa.setLongitude(editTextLongitude.getText().toString());
                mapa.setNome(editTextNome.getText().toString());

                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Mapa");

                reference.push().setValue(mapa);

                Toast.makeText(getApplicationContext(), "Gravado com sucesso!", Toast.LENGTH_SHORT).show();
                editTextNome.setText("");
                editTextLatitude.setText("");
                editTextLongitude.setText("");
                editTextLatitude.requestFocus();
            }
        });

    }
}
