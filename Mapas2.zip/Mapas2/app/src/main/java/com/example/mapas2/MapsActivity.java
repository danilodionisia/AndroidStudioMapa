package com.example.mapas2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import android.app.DownloadManager;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {



    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

        final List<LatLng> cities = new ArrayList<LatLng>();
        /*
        cities.add(new LatLng(-22.74103972, -47.32995987));
        cities.add(new LatLng(-22.7853612, -47.29013443));
        cities.add(new LatLng(-22.75655388, -47.40652084));
        */

        final List<String> nameOfCitie = new ArrayList<String>();
        /*
        nameOfCitie.add("Danilo");
        nameOfCitie.add("Giovan");
        nameOfCitie.add("Guto");
        */


        Query query = FirebaseDatabase.getInstance().getReference("Mapa");
        query.orderByKey().addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                final Mapa m = dataSnapshot.getValue(Mapa.class);
                cities.add(new LatLng(Double.parseDouble(m.getLatitude()), Double.parseDouble(m.getLongitude())));
                nameOfCitie.add(m.getNome());
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        /*
        LatLng PERTH = new LatLng(-22.74103972, -47.32995987);
        LatLng SYDNEY = new LatLng(-22.7853612, -47.29013443);
        LatLng BRISBANE = new LatLng(-22.75655388, -47.40652084);
        */



        /*
        Marker mPerth;
        Marker mSydney;
        Marker mBrisbane;

        mPerth = mMap.addMarker(new MarkerOptions()
                .position(PERTH)
                .title("Perth"));
        mPerth.setTag(0);

        mSydney = mMap.addMarker(new MarkerOptions()
                .position(SYDNEY)
                .title("Sydney"));
        mSydney.setTag(0);

        mBrisbane = mMap.addMarker(new MarkerOptions()
                .position(BRISBANE)
                .title("Brisbane"));
        mBrisbane.setTag(0);
        */

        Marker []markers = new Marker[nameOfCitie.size()];

        for(int i = 0; i < 3; i++){

            markers[i] = mMap.addMarker(new MarkerOptions()
                    .position(cities.get(i))
                    .title(nameOfCitie.get(i))
            );

            markers[i].setTag(0);

        }

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(cities.get(0), 11));

    }

}
